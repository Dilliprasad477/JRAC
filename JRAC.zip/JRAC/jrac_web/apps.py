from __future__ import unicode_literals

from django.apps import AppConfig


class Jrac_WebConfig(AppConfig):
    name = 'jrac_web'
    #name = 'jrac_web'

