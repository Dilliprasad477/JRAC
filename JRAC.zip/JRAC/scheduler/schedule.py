import glob
import os
import time

from analyzer.models import Project, Test
from controller.views import generate_test_results_data


def upload_file_auto():
    projects = Project.objects.values()
    csv_file_fields = "response_time,url,responseCode,responseMessage,threadName,dataType,success,failureMessage,bytes,sentBytes,grpThreads,allThreads,Latency,IdleTime,Connect"
    files = glob.glob('D:\\JRA\\JRAC_JTL\\*.jtl')
    filepath = max(files, key=os.path.getctime)
    fileName = os.path.basename(filepath)
    nameList=list(fileName.split('_'))
    project_id=None
    for project_Name in projects:
        if nameList[0] == project_Name['project_name']:
            project_id=project_Name['id']
            break
    if project_id == None:
        project = Project(project_name=nameList[0], )
        project.save()
        project_id = project.id
    test = Test(
        project_id = project_id,
        display_name = nameList[1],
        show=True,
        start_time=int(time.time() * 1000))
    test.save()
    test_id = test.id
    path = filepath
    print(path)
    csv_file_fields = csv_file_fields.split(',')
    generate_test_results_data(test_id,
                                    project_id, path,
                                    jmeter_results_file_fields=csv_file_fields)

