from __future__ import unicode_literals

from django.apps import AppConfig


class Jra_WebConfig(AppConfig):
    name = 'jra_web'
    #name = 'jra_web'

