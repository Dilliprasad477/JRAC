from __future__ import unicode_literals

from django.apps import AppConfig


class AnalyzerConfig(AppConfig):
    name = 'analyzer'
    def ready(self):
        from scheduler import updater
        updater.start()
