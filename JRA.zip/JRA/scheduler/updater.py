from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from scheduler import schedule

def start():
    scheduler = BackgroundScheduler()
    scheduler.add_job(schedule.upload_file_auto,'interval', minutes=2)
    scheduler.start()